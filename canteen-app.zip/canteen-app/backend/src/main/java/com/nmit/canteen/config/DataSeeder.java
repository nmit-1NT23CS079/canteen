package com.nmit.canteen.config;

import com.nmit.canteen.model.MenuItem;
import com.nmit.canteen.model.User;
import com.nmit.canteen.repository.MenuItemRepository;
import com.nmit.canteen.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

/** Seeds demo data. Admin: admin@canteen.com / admin123 | Student: student@canteen.com / student123 */
@Component
public class DataSeeder implements CommandLineRunner {
    private final MenuItemRepository menu;
    private final UserRepository users;
    private final PasswordEncoder encoder;

    public DataSeeder(MenuItemRepository menu, UserRepository users, PasswordEncoder encoder) {
        this.menu = menu; this.users = users; this.encoder = encoder;
    }

    @Override
    public void run(String... args) {
        users.save(new User("Canteen Admin", "admin@canteen.com", encoder.encode("admin123"), "ADMIN"));
        users.save(new User("Demo Student", "student@canteen.com", encoder.encode("student123"), "STUDENT"));

        menu.save(new MenuItem("Masala Dosa", "Breakfast", 60, true, true, "Crispy dosa with spicy potato filling"));
        menu.save(new MenuItem("Idli Vada", "Breakfast", 45, true, false, "Soft idlis with crunchy vada and sambar"));
        menu.save(new MenuItem("Poori Bhaji", "Breakfast", 50, true, false, "Fluffy poori with potato bhaji"));
        menu.save(new MenuItem("Veg Fried Rice", "Meals", 90, true, false, "Wok tossed rice with vegetables"));
        menu.save(new MenuItem("Chicken Biryani", "Meals", 140, false, true, "Spicy hyderabadi style chicken biryani"));
        menu.save(new MenuItem("Paneer Butter Masala Meal", "Meals", 120, true, true, "Paneer curry with chapati and rice"));
        menu.save(new MenuItem("Egg Fried Rice", "Meals", 100, false, false, "Egg and rice stir fried"));
        menu.save(new MenuItem("Veg Puff", "Snacks", 25, true, false, "Flaky puff with vegetable stuffing"));
        menu.save(new MenuItem("Samosa", "Snacks", 20, true, true, "Spicy potato samosa"));
        menu.save(new MenuItem("Chicken Roll", "Snacks", 70, false, true, "Spicy chicken roll"));
        menu.save(new MenuItem("French Fries", "Snacks", 55, true, false, "Salted crispy fries"));
        menu.save(new MenuItem("Filter Coffee", "Beverages", 20, true, false, "Fresh South Indian filter coffee"));
        menu.save(new MenuItem("Masala Chai", "Beverages", 15, true, false, "Ginger masala tea"));
        menu.save(new MenuItem("Cold Coffee", "Beverages", 50, true, false, "Chilled coffee with ice cream"));
        menu.save(new MenuItem("Fresh Lime Soda", "Beverages", 30, true, false, "Sweet or salted lime soda"));
    }
}
